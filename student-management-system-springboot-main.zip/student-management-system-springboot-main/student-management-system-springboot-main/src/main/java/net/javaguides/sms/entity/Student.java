package net.javaguides.sms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employees")
public class Student 
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "Name", nullable = false)
	private String name;
	
	@Column(name = "Address")
	private String Address;
	
	@Column(name = "Dept_Code")
	private String Dept_Code;
	
	@Column(name="Dept_Name")
	private String Dept_Name;
	
	public Student() {
		
	}
	

	public Student(Long id, String name, String address, String dept_Code, String dept_Name) {
		super();
		this.id = id;
		this.name = name;
		Address = address;
		Dept_Code = dept_Code;
		Dept_Name = dept_Name;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getDept_Code() {
		return Dept_Code;
	}

	public void setDept_Code(String dept_Code) {
		Dept_Code = dept_Code;
	}

	public String getDept_Name() {
		return Dept_Name;
	}

	public void setDept_Name(String dept_Name) {
		Dept_Name = dept_Name;
	}
	
	
	
}
